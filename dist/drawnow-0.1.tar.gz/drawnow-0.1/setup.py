from distutils.core import setup

setup(name='drawnow',
        author='Scott Sievert',
        author_email='sieve121@umn.edu',
        url='https://github.com/scottsievert/python-drawnow',
        version='0.1',
        py_modules=['drawnow'],
        )
